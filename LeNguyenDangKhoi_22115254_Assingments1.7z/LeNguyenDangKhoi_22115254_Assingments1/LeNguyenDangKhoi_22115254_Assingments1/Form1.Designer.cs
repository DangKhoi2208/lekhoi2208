﻿namespace LeNguyenDangKhoi_22115254_Assingments1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_do = new System.Windows.Forms.Panel();
            this.panel_vang = new System.Windows.Forms.Panel();
            this.panel_xanh = new System.Windows.Forms.Panel();
            this.but_End = new System.Windows.Forms.Button();
            this.but_Start = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_doon = new System.Windows.Forms.Panel();
            this.panel_vangon = new System.Windows.Forms.Panel();
            this.panel_xanhon = new System.Windows.Forms.Panel();
            this.but_ondo = new System.Windows.Forms.Button();
            this.but_onvang = new System.Windows.Forms.Button();
            this.but_onxanh = new System.Windows.Forms.Button();
            this.panel_vangoff = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel_xanhoff = new System.Windows.Forms.Panel();
            this.panel_dooff = new System.Windows.Forms.Panel();
            this.but_offdo = new System.Windows.Forms.Button();
            this.but_offvang = new System.Windows.Forms.Button();
            this.but_offxanh = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel_vangoff.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_do
            // 
            this.panel_do.BackColor = System.Drawing.Color.Red;
            this.panel_do.Location = new System.Drawing.Point(40, 20);
            this.panel_do.Name = "panel_do";
            this.panel_do.Size = new System.Drawing.Size(117, 86);
            this.panel_do.TabIndex = 0;
            // 
            // panel_vang
            // 
            this.panel_vang.BackColor = System.Drawing.Color.Yellow;
            this.panel_vang.Location = new System.Drawing.Point(203, 20);
            this.panel_vang.Name = "panel_vang";
            this.panel_vang.Size = new System.Drawing.Size(117, 86);
            this.panel_vang.TabIndex = 1;
            // 
            // panel_xanh
            // 
            this.panel_xanh.BackColor = System.Drawing.Color.Lime;
            this.panel_xanh.Location = new System.Drawing.Point(365, 20);
            this.panel_xanh.Name = "panel_xanh";
            this.panel_xanh.Size = new System.Drawing.Size(117, 86);
            this.panel_xanh.TabIndex = 1;
            // 
            // but_End
            // 
            this.but_End.Location = new System.Drawing.Point(141, 14);
            this.but_End.Name = "but_End";
            this.but_End.Size = new System.Drawing.Size(72, 58);
            this.but_End.TabIndex = 2;
            this.but_End.Text = "Kết thúc";
            this.but_End.UseVisualStyleBackColor = true;
            this.but_End.Click += new System.EventHandler(this.button1_Click);
            // 
            // but_Start
            // 
            this.but_Start.Location = new System.Drawing.Point(24, 14);
            this.but_Start.Name = "but_Start";
            this.but_Start.Size = new System.Drawing.Size(72, 58);
            this.but_Start.TabIndex = 3;
            this.but_Start.Text = "Bắt đầu";
            this.but_Start.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.panel1.Controls.Add(this.but_offxanh);
            this.panel1.Controls.Add(this.but_offvang);
            this.panel1.Controls.Add(this.but_offdo);
            this.panel1.Controls.Add(this.panel_dooff);
            this.panel1.Controls.Add(this.panel_xanhoff);
            this.panel1.Controls.Add(this.panel_vangoff);
            this.panel1.Controls.Add(this.but_onxanh);
            this.panel1.Controls.Add(this.but_onvang);
            this.panel1.Controls.Add(this.but_ondo);
            this.panel1.Controls.Add(this.panel_vangon);
            this.panel1.Controls.Add(this.panel_xanhon);
            this.panel1.Controls.Add(this.panel_doon);
            this.panel1.Controls.Add(this.but_Start);
            this.panel1.Controls.Add(this.but_End);
            this.panel1.Location = new System.Drawing.Point(526, 20);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(228, 325);
            this.panel1.TabIndex = 4;
            // 
            // panel_doon
            // 
            this.panel_doon.BackColor = System.Drawing.Color.Red;
            this.panel_doon.Location = new System.Drawing.Point(3, 96);
            this.panel_doon.Name = "panel_doon";
            this.panel_doon.Size = new System.Drawing.Size(48, 41);
            this.panel_doon.TabIndex = 4;
            // 
            // panel_vangon
            // 
            this.panel_vangon.BackColor = System.Drawing.Color.Yellow;
            this.panel_vangon.Location = new System.Drawing.Point(3, 172);
            this.panel_vangon.Name = "panel_vangon";
            this.panel_vangon.Size = new System.Drawing.Size(48, 41);
            this.panel_vangon.TabIndex = 5;
            // 
            // panel_xanhon
            // 
            this.panel_xanhon.BackColor = System.Drawing.Color.Lime;
            this.panel_xanhon.Location = new System.Drawing.Point(3, 253);
            this.panel_xanhon.Name = "panel_xanhon";
            this.panel_xanhon.Size = new System.Drawing.Size(48, 41);
            this.panel_xanhon.TabIndex = 5;
            // 
            // but_ondo
            // 
            this.but_ondo.Location = new System.Drawing.Point(52, 96);
            this.but_ondo.Name = "but_ondo";
            this.but_ondo.Size = new System.Drawing.Size(44, 23);
            this.but_ondo.TabIndex = 7;
            this.but_ondo.Text = "ON";
            this.but_ondo.UseVisualStyleBackColor = true;
            this.but_ondo.Click += new System.EventHandler(this.button4_Click);
            // 
            // but_onvang
            // 
            this.but_onvang.Location = new System.Drawing.Point(52, 172);
            this.but_onvang.Name = "but_onvang";
            this.but_onvang.Size = new System.Drawing.Size(44, 23);
            this.but_onvang.TabIndex = 9;
            this.but_onvang.Text = "ON";
            this.but_onvang.UseVisualStyleBackColor = true;
            // 
            // but_onxanh
            // 
            this.but_onxanh.Location = new System.Drawing.Point(52, 253);
            this.but_onxanh.Name = "but_onxanh";
            this.but_onxanh.Size = new System.Drawing.Size(44, 23);
            this.but_onxanh.TabIndex = 11;
            this.but_onxanh.Text = "ON";
            this.but_onxanh.UseVisualStyleBackColor = true;
            // 
            // panel_vangoff
            // 
            this.panel_vangoff.BackColor = System.Drawing.Color.Yellow;
            this.panel_vangoff.Controls.Add(this.panel8);
            this.panel_vangoff.Location = new System.Drawing.Point(127, 172);
            this.panel_vangoff.Name = "panel_vangoff";
            this.panel_vangoff.Size = new System.Drawing.Size(48, 41);
            this.panel_vangoff.TabIndex = 12;
            // 
            // panel8
            // 
            this.panel8.Location = new System.Drawing.Point(51, 30);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(48, 41);
            this.panel8.TabIndex = 5;
            // 
            // panel_xanhoff
            // 
            this.panel_xanhoff.BackColor = System.Drawing.Color.Lime;
            this.panel_xanhoff.Location = new System.Drawing.Point(127, 253);
            this.panel_xanhoff.Name = "panel_xanhoff";
            this.panel_xanhoff.Size = new System.Drawing.Size(48, 41);
            this.panel_xanhoff.TabIndex = 5;
            // 
            // panel_dooff
            // 
            this.panel_dooff.BackColor = System.Drawing.Color.Red;
            this.panel_dooff.Location = new System.Drawing.Point(127, 96);
            this.panel_dooff.Name = "panel_dooff";
            this.panel_dooff.Size = new System.Drawing.Size(48, 41);
            this.panel_dooff.TabIndex = 13;
            // 
            // but_offdo
            // 
            this.but_offdo.Location = new System.Drawing.Point(178, 96);
            this.but_offdo.Name = "but_offdo";
            this.but_offdo.Size = new System.Drawing.Size(44, 23);
            this.but_offdo.TabIndex = 15;
            this.but_offdo.Text = "OFF";
            this.but_offdo.UseVisualStyleBackColor = true;
            this.but_offdo.Click += new System.EventHandler(this.button10_Click);
            // 
            // but_offvang
            // 
            this.but_offvang.Location = new System.Drawing.Point(178, 172);
            this.but_offvang.Name = "but_offvang";
            this.but_offvang.Size = new System.Drawing.Size(44, 23);
            this.but_offvang.TabIndex = 16;
            this.but_offvang.Text = "OFF";
            this.but_offvang.UseVisualStyleBackColor = true;
            // 
            // but_offxanh
            // 
            this.but_offxanh.Location = new System.Drawing.Point(178, 253);
            this.but_offxanh.Name = "but_offxanh";
            this.but_offxanh.Size = new System.Drawing.Size(44, 19);
            this.but_offxanh.TabIndex = 19;
            this.but_offxanh.Text = "OFF";
            this.but_offxanh.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_vang);
            this.Controls.Add(this.panel_xanh);
            this.Controls.Add(this.panel_do);
            this.Name = "Form1";
            this.Text = "form1";
            this.panel1.ResumeLayout(false);
            this.panel_vangoff.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_do;
        private System.Windows.Forms.Panel panel_vang;
        private System.Windows.Forms.Panel panel_xanh;
        private System.Windows.Forms.Button but_End;
        private System.Windows.Forms.Button but_Start;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button but_onxanh;
        private System.Windows.Forms.Button but_onvang;
        private System.Windows.Forms.Button but_ondo;
        private System.Windows.Forms.Panel panel_vangon;
        private System.Windows.Forms.Panel panel_xanhon;
        private System.Windows.Forms.Panel panel_doon;
        private System.Windows.Forms.Button but_offxanh;
        private System.Windows.Forms.Button but_offvang;
        private System.Windows.Forms.Button but_offdo;
        private System.Windows.Forms.Panel panel_dooff;
        private System.Windows.Forms.Panel panel_xanhoff;
        private System.Windows.Forms.Panel panel_vangoff;
        private System.Windows.Forms.Panel panel8;
    }
}

